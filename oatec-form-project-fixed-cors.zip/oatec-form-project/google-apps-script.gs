const SPREADSHEET_ID = "PEGAR_AQUI_EL_ID_DE_TU_GOOGLE_SHEET";
const SHEET_NAME = "Inscripciones OATec";

function getOrCreateSheet_() {
  const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = spreadsheet.insertSheet(SHEET_NAME);
  }

  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "Fecha de registro",
      "Nombres",
      "Apellidos",
      "Edad",
      "Fecha de nacimiento",
      "DNI",
      "Curso",
      "División",
      "Institución",
      "Competencia",
      "Temática",
      "Timestamp ISO"
    ]);
  }

  return sheet;
}

function parseRequestData_(e) {
  if (!e) return {};

  if (e.postData && e.postData.contents) {
    const content = e.postData.contents;

    try {
      return JSON.parse(content);
    } catch (jsonError) {
      // Si no es JSON, seguimos con e.parameter
    }
  }

  return e.parameter || {};
}

function doPost(e) {
  try {
    const data = parseRequestData_(e);
    const sheet = getOrCreateSheet_();

    sheet.appendRow([
      new Date(),
      data.firstName || "",
      data.lastName || "",
      data.age || "",
      data.birthDate || "",
      data.dni || "",
      data.course || "",
      data.division || "",
      data.institution || "Instituto San Miguel",
      data.competition || "OATec ITBA 2026",
      data.theme || "Desafío Espacial",
      data.createdAt || ""
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({
        result: "success",
        message: "Inscripción guardada correctamente"
      }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({
        result: "error",
        message: String(error)
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput("OATec form endpoint OK")
    .setMimeType(ContentService.MimeType.TEXT);
}
